package com.cg.service;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

import com.cd.dao.DataStorage;
import com.cg.bean.Bank;
import com.cg.presentation.CreateAccount;


public class Service {

	public void randomaccnum(String accnum,Bank bank) {
		// TODO Auto-generated method stub
		   // System.out.println("Your account number is " + bank.getAccnum());
		    DataStorage dsObj = new DataStorage();
		    dsObj.storeData(bank);
		}

	public void balance() {
		// TODO Auto-generated method stub
		
	}
	
	public void dataDeposit(Bank bank,int acc) {
		// TODO Auto-generated method stub
		int premoney=0,addmoney,totalBal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your account number");
		int newaccnum = sc.nextInt();
		
		//System.out.println("old account number " + bank.getAccnum());
		
		if(newaccnum==(bank.getAccnum())) {
			System.out.println("Deposit your money");
			addmoney = sc.nextInt();
			totalBal = premoney + addmoney;
			System.out.println("Your balance is " + totalBal);
			bank.setAddmoney(totalBal);
		}
		else
			System.out.println("Enter valid account number");
	}

	public void withDrawal(Bank bank,int totalBal) {
		// TODO Auto-generated method stub
		int totalBal,withdrawmoney,remainingBal;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your account number");
		int newaccnum = sc.nextInt();
		
		//System.out.println("old account number " + bank.getAccnum());
		
		if(newaccnum==(bank.getAccnum())) {
			System.out.println("Withdraw your money");
			withdrawmoney = sc.nextInt();
			remainingBal = totalBal - withdrawmoney;
			System.out.println("Your balance is " + remainingBal);
			bank.setAddmoney(remainingBal);
		}
		else
			System.out.println("Enter valid account number");
	}
		

	public void fundTrans() {
		// TODO Auto-generated method stub
		
	}
	
	//Passing data from database to service layer
	public void show(ArrayList<String> arraylist) {
		// TODO Auto-generated method stub
		CreateAccount obj1 = new CreateAccount();
		obj1.showOutput(arraylist);
	}
}
