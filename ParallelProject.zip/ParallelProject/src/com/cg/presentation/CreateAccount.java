package com.cg.presentation;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.Bank;
import com.cg.service.Service;
public class CreateAccount {

	public void accountDetails() {
		// TODO Auto-generated method stub
		String firstName;
		String lastName;
		String phoneNumber;
		String accnum = null ;
		String address;
		
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		
		Bank bank = new Bank(); 
		System.out.println("Enter your firstname");
		firstName = sc.nextLine();
		bank.setFirstName(firstName);
		
		System.out.println("Enter your lastname");
		lastName = sc.nextLine();
		bank.setLastName(lastName);
		
		System.out.println("Enter your phonenumber");
		phoneNumber = sc.nextLine();
		bank.setPhoneNumber(phoneNumber);
		
		System.out.println("Enter your address");
		address = sc.nextLine();
		bank.setAddress(address);
		
		Service calcservice = new Service();
		calcservice.randomaccnum(accnum, bank);
		
		sc.close();
		sc1.close();
	}

	public void showOutput(ArrayList<String> arraylist) {
		// TODO Auto-generated method stub
		for(String str : arraylist) {
            System.out.println(str);
        }
	}

}
