package com.cg.presentation;

public class PrintTransactions {

	public void printTransaction() {
		// TODO Auto-generated method stub
		
	}

}
