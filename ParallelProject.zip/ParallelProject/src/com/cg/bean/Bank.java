package com.cg.bean;

public class Bank {
	
	String firstName;
	String lastName;
	String phoneNumber;
	int accnum=34567891;
	String address;
	int remainingBal;
	int totalBal;

	public int getTotalBal() {
		return totalBal;
	}
	public void setTotalBal(int totalBal) {
		this.totalBal = totalBal;
	}
	public int getRemainingBal() {
		return remainingBal;
	}
	public void setRemainingBal(int remainingBal) {
		this.remainingBal = remainingBal;
	}
	int addmoney;
//	public int setAddmoney;
	public int getAccnum() {
		return accnum;
	}
	public int getAddmoney() {
		return addmoney;
	}
	public void setAddmoney(int addmoney) {
		this.addmoney = addmoney;
	}
	public void setAccnum(int accnum) {
		this.accnum = accnum;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
