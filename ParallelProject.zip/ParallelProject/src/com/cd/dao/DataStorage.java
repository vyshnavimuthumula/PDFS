package com.cd.dao;

import java.util.ArrayList;

import com.cg.bean.Bank;
import com.cg.service.Service;

public class DataStorage {
	public void storeData(Bank bank) {
		ArrayList<String> arraylist = new ArrayList<String>();
		System.out.println("Bank account details");
		arraylist.add("First name  : " + bank.getFirstName());
		arraylist.add("Last name  : " + bank.getLastName());
		arraylist.add("Phone number  : " + bank.getPhoneNumber());
		arraylist.add("Account number " + bank.getAccnum());
		
		Service s = new Service();
		s.show(arraylist);
		
	}
}
