package com.cg.bean;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.service.ValidationClass;

public class BankDetails
{
	Scanner sc=new Scanner(System.in);
	ValidationClass vc=new ValidationClass();
	private String name;
	private int pinNumber;
	private String mobileNumber;
	private String adhaarNo;
	private int balance;
	private double accountNo;
	private static double acctNo=1000;
	private List<String> list = new ArrayList<String>();
	public  double getAcctno() {
		return acctNo;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) 
	{
		if(vc.checkNumber(mobileNumber))
		{
		this.mobileNumber = mobileNumber;
		}
		else 
		{
			System.out.println("Enter valid Mobile Number");
			
			setMobileNumber(sc.next());
		}
	}
	public String getAdhaarNo() {
		return adhaarNo;
	}
	public void setAdhaarNo(String adhaarNo)
	{
		if(vc.checkAdhaar(adhaarNo))
	    {
		this.adhaarNo = adhaarNo;
		}
		else
		{
			System.out.println("Enter 12 digit Adhaar Number");
			setAdhaarNo(sc.next());
		}
	}
	public String getName() {
		return name;
	}
	public void setName(String name)
	{
		if(vc.checkName(name))
		{
		this.name = name;
		}
		else
		{
			System.out.println("Enter Valid Name:");
			setName(sc.next());
		}
	}
	public int getPin() {
		return pinNumber;
	}
	public void setPin(int pin) 
	{
		//if(vc.setPin(pin))
		//{
		this.pinNumber = pin;
		//}
		//else
		//{
			//System.out.println("Pin Number should not exceed 4 digits");
			//setPin(sc.next());
		//}
	}
	public BankDetails() {}
	public BankDetails(String name, int pinNumber, String mobileNumber, String adhaarNo, int balance, double accountNo) {
		super();
		this.name = name;
		this.pinNumber = pinNumber;
		this.mobileNumber = mobileNumber;
		this.adhaarNo = adhaarNo;
		this.balance = balance;
		this.accountNo = accountNo;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public double getAccountno() {
		return accountNo;
	}
	public void setAccountno() {
		accountNo = ++acctNo;
	}
	
	public List<String> getList() {
		return list;
	}

	public void setList(String string) {
	
		list.add(string);
		this.list = list;
		
	}
	@Override
	public String toString() {
		return "BankDetails [name=" + name + ", pinNumber=" + pinNumber + ", mobileNumber=" + mobileNumber
				+ ", adhaarNo=" + adhaarNo + ", balance=" + balance + ", accountNo=" + accountNo + ", list=" + list
				+ "]";
	}


}
