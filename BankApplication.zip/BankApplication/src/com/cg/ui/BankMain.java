package com.cg.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.service.BankServiceClass;

public class BankMain
{
	public static void main(String[] args)
	{
    	BankServiceClass bank=new BankServiceClass();
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome to Akhila Company");
	for(;;)
		{
		System.out.println(" 1.create Account\n 2. Show Balance\n 3. Deposit\n 4. Withdraw\n 5.Fund Transfer\n 6. Print Transactions\n");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: bank.createAccount();
			         break;
			case 2: System.out.println(bank.showBalance());
			         break;
			         
			case 3: bank.deposit();
			          break;
			case 4:
				bank.withDraw();
				break;
			case 5:
				 bank.fundTransfer();
				break;
			case 6:
				List<String> l1=new ArrayList<String>();
				l1=bank.printTransactions();
				Iterator<String> itr=l1.iterator();
				while(itr.hasNext()){
					System.out.println(itr.next());
				}
				    break;
			
				default: System.out.println("please enter valid choice");
			}
		
		System.out.println("Press 1 to Continue or 2 to exit");
		if(sc.nextInt()==1)
		{
			continue;
		}
		else
		{
			System.exit(0);
		}
	}
	}
}
