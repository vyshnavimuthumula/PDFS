package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.BankDetails;

public class BankDatabase
{
	static List<BankDetails> list=new ArrayList<BankDetails>();
	static{
		BankDetails b1 = new BankDetails("Sanjay",1234,"9897969594","987654321234",50000,1000);
		BankDetails b2 = new BankDetails("Akhila",3688,"6578987867","987654321234",10000,1222);
		BankDetails b3 = new BankDetails("Bharathi",3756,"8578987867","987654321234",12556,1366);
		BankDetails b4 = new BankDetails("Srilekha",6753,"7578676892","987654321234",5542,1566);
		list.add(b1);
		list.add(b2);
		list.add(b3);
		list.add(b4);	
}
	private double accountNo;
public void storeCustDetails(BankDetails bdetails) {
		
		list.add(bdetails);
		System.out.println(list);
}
	public BankDetails showAccountBalance(double accountno,int pin) {
	BankDetails bdetails=new BankDetails();
		for(BankDetails b1:list)
		{
		if(b1.getAccountno()==accountno)
		{
			bdetails=b1;
			break;
		}
		}
		
		return bdetails;		
	}
	public void deposit(double accountno, int amt) {
		
		BankDetails b=new BankDetails();
		for(BankDetails b1:list){
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		b.setBalance(b.getBalance()+amt);
		System.out.println("amount successfully deposited");
		System.out.println("new balance:"+b.getBalance());
		b.setList(+amt+ " rupees successfully deposited");
		
	
	}
	public void fundTransfer(double accountno, double acctto, int amt) {
		BankDetails b=new BankDetails();
		for(BankDetails b1:list){
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		BankDetails b2=new BankDetails();
		for(BankDetails bt:list){
			if(bt.getAccountno()==acctto)
			{
				b2=bt;
				break;
			}
				}
		if(b.getAccountno()!=b2.getAccountno())
		{	
		
		if(b.getBalance()>amt)
		{
				b.setBalance(b.getBalance()-amt);
			
				System.out.println("Amount successfull credited and deposited to required acccount no");
				System.out.println("new balance:"+b.getBalance());
				b2.setBalance(b.getBalance()+amt);
				b.setList(+amt+ "rupees Amount succcesfully transferred to required account:");
		}
			else
				System.out.println("Insufficient amount in your account");
		}
		else
		{
			System.out.println("acccounts are same and hence funds cannot be transferred");
		}
	}
	public List<String> printTransction(double Accountno) {
		BankDetails b=new BankDetails();
		for(BankDetails b1:list)
		if(b1.getAccountno()== Accountno)
		{
			b=b1;
			break;
		}
		return b.getList();
		
		}
	public double checkAccountNo(double accountno) 
	{
		int b = 0;
		for(BankDetails b1 : list) { 
			   if(b1.getAccountno()==accountno)
			   {
				   b=1;
				  return accountno;
			   }
			}
		if(b==0)
		{
			System.out.println("please enter a valid account number");
		}
	return 1;

		
	}
	
	

	public int checkPin(int pin) {
		int c = 0;
		for(BankDetails b1 : list) { 
			   if(b1.getPin()==pin)
			   {
				   c=1;
				  return 0;
			   }
			}
		if(c==0)
		{
			System.out.println("please enter a valid pin");
		}
	return 1;
	}
	public void withDraw(double accountno, int amt) {
		BankDetails b=new BankDetails();
		for(BankDetails b1:list){
		if(b1.getAccountno()==accountno)
		{
			b=b1;
			break;
		}
		}
		if(b.getBalance()>amt){
			b.setBalance(b.getBalance()-amt);
			System.out.println("amount sucessfully withdrawn");
			System.out.println(b.getBalance());
			b.setList(+amt+ " rupees Amount withrawn");
		}
		
	}	
}


