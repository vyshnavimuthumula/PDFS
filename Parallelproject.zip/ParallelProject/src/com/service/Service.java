package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.bean.Bank;
import com.dao.DataStorage;

public class Service {
	List<Bank> list=new ArrayList<Bank>();
	Scanner sc = new Scanner(System.in);
	DataStorage database=new DataStorage();
	
	public Bank balance() {
		double accountno;
		int pin;
			System.out.println("enter account number");
			accountno = sc.nextDouble();
			System.out.println("enter your pin");
			pin=sc.nextInt();
			if((checkAccountNo(accountno)==1)&&(checkPin(pin)==1))
				return showAccountBalance(accountno,pin);
			return null;			
					
	}
	public double checkAccountNo(double accountno) {
		int b = 0;
		for(Bank b1 : list) { 
			   if(b1.getAccnum()==accountno){
				   b=1;
				  return accountno;
			   }
			}
		if(b==0)
			System.out.println("please enter a valid account number");
		return 1;		
	}
	public int checkPin(int pin) {
		int c = 0;
		for(Bank b1 : list) { 
			   if(b1.getPin()==pin){
				   c=1;
				  return 0;
			   }
			}
		if(c==0)
			System.out.println("please enter a valid pin");
	return 1;
	}
	public Bank showAccountBalance(double accountno,int pin) {
		Bank bank=new Bank();
			for(Bank b1:list){
				if(b1.getAccnum()==accountno){
					bank=b1;
					break;
				}
			}			
			return bank;		
		}
	
	
	public void dataDeposit(Bank bank, int accnum) {
		double accountno;
		System.out.println("enter the account no");
		accountno = sc.nextDouble();
		if(checkAccountNo(accountno)==1){
			System.out.println("enter the amount to be depoist:");
			int amount = sc.nextInt();
			database.deposit(accountno, amount);	
		}
	}

	public void withDrawal(Bank bank, int accnum) {
		// TODO Auto-generated method stub
		
	}

	public void fundTrans() {
		// TODO Auto-generated method stub
		
	}

}
