package com.presentation;

import java.util.Scanner;

import com.bean.Bank;
import com.service.Service;

public class Main {
	public static void main(String[] args) {
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. Create account");
		System.out.println("2. Show balance");
		System.out.println("3. Deposit");
		System.out.println("4. Withdraw");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		
		n = sc.nextInt();
		Bank bank = new Bank();
		
		switch(n) {
		case 1:
			CreateAccount createacc= new CreateAccount();
			createacc.accountDetails();
			break;
		case 2:
			Service showbal = new Service();
			showbal.balance();
			break;
		case 3:
			Service deposit = new Service();
			deposit.dataDeposit(bank,bank.getAccnum());
			break;
		case 4:
			Service  withdraw = new Service();
			withdraw.withDrawal(bank,bank.getAccnum());
			break;
		case 5:
			Service fund = new Service ();
			fund.fundTrans();
			break;
		case 6:
			PrintTransactions print = new PrintTransactions();
			print.printTransaction();
			break;
		default:
			System.out.println("Enter valid option");
		}
		sc.close();
	}
}
