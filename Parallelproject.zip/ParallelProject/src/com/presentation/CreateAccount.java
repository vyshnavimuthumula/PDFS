package com.presentation;

import java.util.Scanner;

import com.bean.Bank;
import com.dao.DataStorage;

public class CreateAccount {
	
	Scanner sc = new Scanner(System.in);
	Bank bank = new Bank();
	DataStorage database = new DataStorage();
	public void accountDetails() {
		// TODO Auto-generated method stub
		System.out.print("Enter your name:");
		bank.setName(sc.next());
		System.out.print("Enter Adhaar details:");
		bank.setAdharNum(sc.next());
		System.out.print("Enter your Mobile Number:");
		bank.setPhoneNum(sc.next());
		bank.getAccnum();
		System.out.println("set the pin to the account");
		bank.setPin(sc.nextInt());
		System.out.println("Enter the amount to be deposited");
		bank.setBalance(sc.nextInt());
		System.out.println("Account created successfully");
		database.storeCustomerDetails(bank);
	}

}
