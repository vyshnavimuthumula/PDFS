package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.bean.Bank;

public class DataStorage {
	List<Bank> list=new ArrayList<Bank>();
	public void storeCustomerDetails(Bank bank) {
		list.add(bank);
		System.out.println("Your account details are " + list);
	}
	public void deposit(double accountno, int amt) {
		Bank b=new Bank();
		for(Bank b1:list){
			if(b1.getAccnum()==accountno)
			{
				b=b1;
				break;
			}
		}
		b.setBalance(b.getBalance()+amt);
		System.out.println("amount successfully deposited");
		System.out.println("new balance:"+b.getBalance());
		
	}
}
